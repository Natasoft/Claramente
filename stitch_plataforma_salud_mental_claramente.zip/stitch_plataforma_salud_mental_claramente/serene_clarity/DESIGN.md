---
name: Serene Clarity
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#49454f'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#7a7580'
  outline-variant: '#cbc4d0'
  surface-tint: '#68548d'
  primary: '#68548d'
  on-primary: '#ffffff'
  primary-container: '#b39ddb'
  on-primary-container: '#453268'
  inverse-primary: '#d3bcfc'
  secondary: '#3c6842'
  on-secondary: '#ffffff'
  secondary-container: '#bdefbe'
  on-secondary-container: '#426e47'
  tertiary: '#666018'
  on-tertiary: '#ffffff'
  tertiary-container: '#b2aa5a'
  on-tertiary-container: '#433e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ebdcff'
  primary-fixed-dim: '#d3bcfc'
  on-primary-fixed: '#230f45'
  on-primary-fixed-variant: '#503d73'
  secondary-fixed: '#bdefbe'
  secondary-fixed-dim: '#a2d3a4'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#24502c'
  tertiary-fixed: '#efe58f'
  tertiary-fixed-dim: '#d2c976'
  on-tertiary-fixed: '#1f1c00'
  on-tertiary-fixed-variant: '#4e4800'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
  lila-suave: '#B39DDB'
  verde-menta: '#A5D6A7'
  warm-grey: '#E0E0E0'
  ink-dark: '#2C2C2C'
  calm-peach: '#FFCCBC'
typography:
  display-lg:
    fontFamily: Gabriela
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Gabriela
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-md:
    fontFamily: Gabriela
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-md-mobile:
    fontFamily: Gabriela
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  title-lg:
    fontFamily: Gabriela
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 28px
  body-lg:
    fontFamily: Gabriela
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Gabriela
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Gabriela
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Gabriela
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  sidebar-width: 280px
---

## Brand & Style

The brand personality is empathetic, professional, and deeply grounded. It aims to evoke a sense of "digital sanctuary"—a safe space where users feel heard and supported without the overwhelming stimulus of traditional social platforms. The target audience includes individuals seeking emotional support, counseling, or mental health resources, requiring an interface that prioritizes psychological safety and cognitive ease.

The design style is **Modern Minimalism with Soft Tactility**. By utilizing generous white space, a muted pastel palette, and subtle elevation, the system avoids visual "noise" that can trigger anxiety. It leans into high-quality serif typography to establish an authoritative yet warm editorial feel, ensuring the product feels like a trusted companion rather than a clinical tool.

## Colors

The palette is centered on "Soft Lilac" as the primary driver of the experience, chosen for its associations with spirituality, calm, and introspection. "Mint Green" serves as the secondary color, providing a natural, growth-oriented accent that balances the coolness of the lilac.

To maintain high accessibility and reduce eye strain, the background is an "Off-white" (#F8F9FA), which is softer than pure white. Text is rendered in "Ink-dark" (#2C2C2C) rather than pure black to soften contrast while remaining WCAG AA compliant. Accent pastels are used sparingly for non-critical decorative elements to maintain a sense of warmth without cluttering the hierarchy.

## Typography

The typography relies exclusively on **Gabriela**, a serif face with soft terminals and a rhythmic, gentle cadence. This typeface bridges the gap between academic professionalism and approachable warmth. 

To ensure high accessibility, line heights are set generously (1.5x for body text) to assist users with dyslexia or visual fatigue. Large display sizes are scaled down for mobile devices to prevent excessive scrolling and maintain a clean visual hierarchy. All headings use a slightly tighter letter-spacing to maintain cohesion, while labels use positive letter-spacing to ensure legibility at small sizes.

## Layout & Spacing

This design system uses a **Fluid Grid** model with high-inner-margin containers to create a sense of breathability. The layout is structured around a Bootstrap 5 foundation but modified for a specialized mental health context.

- **Mobile:** A single-column flow with a bottom-anchored or "hamburger" navigation. Margins are kept at 16px to maximize screen real estate for text.
- **Desktop:** A fixed-width sidebar (280px) for persistent navigation, with a main content area that caps at 1200px to maintain comfortable line lengths for reading.
- **Rhythm:** Spacing follows an 8px base unit. Component-to-component spacing is typically 24px or 32px to avoid the feeling of "clutter" that can increase user anxiety.

## Elevation & Depth

To reduce visual anxiety, this system avoids harsh, dark shadows. Instead, it utilizes **Tonal Layers** and **Soft Ambient Shadows**. 

Depth is primarily communicated through subtle shifts in background color (e.g., a card being slightly lighter or darker than the page background). When physical elevation is required for interactivity (like a primary action button or a modal), use an ultra-diffused shadow tinted with the primary Lilac color (e.g., `rgba(179, 157, 219, 0.15)`) rather than a neutral grey. This "tinted glow" feels more organic and less clinical. Glassmorphism is used sparingly on the navbar and sidebar to provide a sense of transparency and light.

## Shapes

The shape language is defined by **Rounded** geometry. There are no sharp corners in the design system, as sharp edges are psychologically associated with precision but also with "threat." 

Standard elements like buttons and input fields utilize a 0.5rem (8px) radius. Larger containers, such as cards and modals, use `rounded-xl` (1.5rem/24px) to create a soft, welcoming container for content. Interactive elements should feel "squishy" and approachable, reinforcing the theme of comfort and support.

## Components

- **Buttons:** Use a pill-shaped or heavily rounded style. The primary button is Soft Lilac with white text. Hover states should use a gentle brightness increase rather than a color shift to avoid jarring transitions.
- **Input Fields:** Fields use a light grey background with a Soft Lilac focus ring (2px). Labels are always visible above the field to reduce cognitive load (no floating labels).
- **Cards:** Cards feature a 1px border in a slightly darker version of the background or a very soft Lilac, with a 24px corner radius. They should not have heavy shadows; a subtle 4px blur is sufficient.
- **Chips/Badges:** Used for mood tracking or categories. These are Mint Green or Calming Peach with a low-opacity fill and high-contrast text.
- **Lists:** List items are separated by generous padding (16px) and soft horizontal lines to keep the interface feeling light.
- **Accessibility Features:** All focus states must be clearly visible using a 3px "halo" in Mint Green. Interactive elements must meet a minimum touch target size of 44x44px for mobile users.
- **Sidebar:** A semi-transparent (glass) sidebar with blurred background keeps the user grounded in their current context while navigating.